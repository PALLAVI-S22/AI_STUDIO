
import React, { useState, useCallback } from 'react';
import TrafficForm from './components/TrafficForm';
import AnalysisDisplay from './components/AnalysisDisplay';
import { NetworkTraffic, AnalysisResult } from './types';
import { analyzeTraffic } from './services/geminiService';

const App: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentResult, setCurrentResult] = useState<AnalysisResult | null>(null);
  const [history, setHistory] = useState<Array<{ traffic: NetworkTraffic; result: AnalysisResult }>>([]);

  const handleAnalysis = useCallback(async (traffic: NetworkTraffic) => {
    setLoading(true);
    setError(null);
    try {
      const result = await analyzeTraffic(traffic);
      setCurrentResult(result);
      setHistory(prev => [{ traffic, result }, ...prev].slice(0, 10));
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred during analysis.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 selection:bg-blue-500/30">
      {/* Header */}
      <nav className="border-b border-slate-800 bg-slate-950/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
            </div>
            <h1 className="text-xl font-bold tracking-tight text-white">
              CyberWatch <span className="text-blue-500">AI</span>
            </h1>
          </div>
          <div className="text-xs font-mono text-slate-500 bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
            SEC_ENGINE_V3.0_ONLINE
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column - Input */}
          <div className="lg:col-span-5 space-y-8">
            <section>
              <div className="mb-4">
                <h2 className="text-2xl font-bold text-white">Traffic Analysis</h2>
                <p className="text-slate-400 text-sm">Enter network details to evaluate threat levels.</p>
              </div>
              <TrafficForm onAnalyze={handleAnalysis} isLoading={loading} />
            </section>

            {/* Error Message */}
            {error && (
              <div className="bg-red-900/20 border border-red-500/50 p-4 rounded-xl flex items-center gap-3 text-red-400 animate-pulse">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                <p className="text-sm font-medium">{error}</p>
              </div>
            )}

            {/* Features Info */}
            <div className="grid grid-cols-2 gap-4">
              <div className="glass p-4 rounded-xl border-slate-800">
                <div className="w-8 h-8 rounded-full bg-green-500/10 flex items-center justify-center mb-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-xs font-bold text-slate-300 uppercase">Real-time Detection</h3>
                <p className="text-[10px] text-slate-500 mt-1">Instant analysis using Gemini 3 Flash technology.</p>
              </div>
              <div className="glass p-4 rounded-xl border-slate-800">
                <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center mb-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                </div>
                <h3 className="text-xs font-bold text-slate-300 uppercase">Heuristic Analysis</h3>
                <p className="text-[10px] text-slate-500 mt-1">Pattern matching for zero-day threat identification.</p>
              </div>
            </div>
          </div>

          {/* Right Column - Results & History */}
          <div className="lg:col-span-7 space-y-8">
            <section>
              {currentResult ? (
                <AnalysisDisplay result={currentResult} />
              ) : (
                <div className="glass h-[400px] rounded-2xl border-dashed border-2 border-slate-800 flex flex-col items-center justify-center text-slate-500 p-8 text-center">
                  <div className="w-16 h-16 bg-slate-900 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-slate-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-slate-400">Awaiting Input</h3>
                  <p className="max-w-xs mt-2 text-sm">Fill in the network parameters and click analyze to see results.</p>
                </div>
              )}
            </section>

            {/* History Table */}
            {history.length > 0 && (
              <section className="glass rounded-2xl overflow-hidden border-slate-800">
                <div className="px-6 py-4 border-b border-slate-800 bg-slate-900/50 flex justify-between items-center">
                  <h3 className="font-bold text-slate-300">Analysis History</h3>
                  <span className="text-[10px] bg-blue-500/10 text-blue-500 px-2 py-0.5 rounded border border-blue-500/20">Last 10 Scans</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="text-xs uppercase text-slate-500 bg-slate-900/30">
                      <tr>
                        <th className="px-6 py-3 font-medium">Source -> Dest</th>
                        <th className="px-6 py-3 font-medium">Risk</th>
                        <th className="px-6 py-3 font-medium">Assessment</th>
                        <th className="px-6 py-3 font-medium text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/50">
                      {history.map((item, idx) => (
                        <tr key={item.traffic.id} className="hover:bg-slate-800/30 transition-colors">
                          <td className="px-6 py-4 font-mono text-xs">
                            <div className="text-slate-200">{item.traffic.sourceIP}</div>
                            <div className="text-slate-500">→ {item.traffic.destIP}</div>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`font-bold ${item.result.riskScore > 60 ? 'text-red-400' : item.result.riskScore > 30 ? 'text-yellow-400' : 'text-green-400'}`}>
                              {item.result.riskScore}%
                            </span>
                          </td>
                          <td className="px-6 py-4 truncate max-w-[200px] text-slate-400 italic">
                            {item.result.isSuspicious ? 'Suspicious activity detected' : 'Normal traffic patterns'}
                          </td>
                          <td className="px-6 py-4 text-right">
                            <button 
                              onClick={() => setCurrentResult(item.result)}
                              className="text-blue-400 hover:text-blue-300 text-xs font-bold transition-colors underline underline-offset-4"
                            >
                              Details
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 mt-20 py-8 text-center text-slate-600 text-xs">
        <p>&copy; 2024 CyberWatch AI. Powered by Google Gemini 3 Flash.</p>
        <p className="mt-1">Intended for educational and security assessment purposes only.</p>
      </footer>
    </div>
  );
};

export default App;

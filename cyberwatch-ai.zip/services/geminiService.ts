
import { GoogleGenAI, Type } from "@google/genai";
import { NetworkTraffic, AnalysisResult } from "../types";

export const analyzeTraffic = async (traffic: NetworkTraffic): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const prompt = `Analyze the following network traffic parameters and determine if they are suspicious.
  
  Parameters:
  - Source IP: ${traffic.sourceIP}
  - Destination IP: ${traffic.destIP}
  - Source Port: ${traffic.sourcePort}
  - Destination Port: ${traffic.destPort}
  - Protocol: ${traffic.protocol}
  - Packet Count: ${traffic.packetCount}
  - Total Bytes: ${traffic.totalBytes}
  - Flags: ${traffic.flags.join(', ') || 'None'}
  
  Identify common patterns like port scanning (many small packets to different ports), DDoS (huge volume to one port), data exfiltration (large outbound bytes), or unusual protocol usage.
  Provide a simple explanation for a non-expert.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      systemInstruction: `You are an elite cybersecurity assistant. Your goal is to analyze specific network parameters and explain in clear, simple language whether the traffic is normal or suspicious. 
      You should output your analysis strictly in JSON format matching the schema provided.
      - riskScore: 0 to 100
      - isSuspicious: true if riskScore > 40
      - explanation: plain language explanation of why it's suspicious or normal.
      - threatType: if suspicious, name the likely threat (e.g., "Potential Port Scan", "Beaconing").
      - recommendation: what the user should do next.
      - confidence: 0.0 to 1.0`,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          isSuspicious: { type: Type.BOOLEAN },
          riskScore: { type: Type.NUMBER },
          explanation: { type: Type.STRING },
          threatType: { type: Type.STRING },
          recommendation: { type: Type.STRING },
          confidence: { type: Type.NUMBER }
        },
        required: ["isSuspicious", "riskScore", "explanation", "recommendation", "confidence"]
      }
    }
  });

  try {
    const data = JSON.parse(response.text || '{}');
    return data as AnalysisResult;
  } catch (error) {
    console.error("Failed to parse AI response:", error);
    throw new Error("Invalid response format from AI");
  }
};

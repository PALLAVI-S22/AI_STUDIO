
export interface NetworkTraffic {
  id: string;
  timestamp: number;
  sourceIP: string;
  destIP: string;
  sourcePort: number;
  destPort: number;
  protocol: 'TCP' | 'UDP' | 'ICMP';
  packetCount: number;
  totalBytes: number;
  flags: string[];
}

export interface AnalysisResult {
  isSuspicious: boolean;
  riskScore: number; // 0-100
  explanation: string;
  threatType?: string;
  recommendation: string;
  confidence: number;
}

export enum ThreatLevel {
  Low = 'Low',
  Medium = 'Medium',
  High = 'High',
  Critical = 'Critical'
}

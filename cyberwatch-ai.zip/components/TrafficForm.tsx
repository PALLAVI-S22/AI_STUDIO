
import React, { useState } from 'react';
import { NetworkTraffic } from '../types';

interface TrafficFormProps {
  onAnalyze: (traffic: NetworkTraffic) => void;
  isLoading: boolean;
}

const TrafficForm: React.FC<TrafficFormProps> = ({ onAnalyze, isLoading }) => {
  const [formData, setFormData] = useState<Omit<NetworkTraffic, 'id' | 'timestamp'>>({
    sourceIP: '192.168.1.15',
    destIP: '8.8.8.8',
    sourcePort: 44332,
    destPort: 443,
    protocol: 'TCP',
    packetCount: 15,
    totalBytes: 1240,
    flags: ['SYN', 'ACK']
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAnalyze({
      ...formData,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
    });
  };

  const handleFlagToggle = (flag: string) => {
    setFormData(prev => ({
      ...prev,
      flags: prev.flags.includes(flag) 
        ? prev.flags.filter(f => f !== flag)
        : [...prev.flags, flag]
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="glass p-6 rounded-2xl space-y-4 cyber-glow">
      <h2 className="text-xl font-bold text-blue-400 mb-4 flex items-center gap-2">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.040L3 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622l-.382-3.016z" />
        </svg>
        Traffic Parameters
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-1">Source IP</label>
          <input
            type="text"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
            value={formData.sourceIP}
            onChange={e => setFormData({ ...formData, sourceIP: e.target.value })}
            placeholder="e.g. 10.0.0.1"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-1">Destination IP</label>
          <input
            type="text"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
            value={formData.destIP}
            onChange={e => setFormData({ ...formData, destIP: e.target.value })}
            placeholder="e.g. 8.8.8.8"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-1">Source Port</label>
          <input
            type="number"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
            value={formData.sourcePort}
            onChange={e => setFormData({ ...formData, sourcePort: parseInt(e.target.value) })}
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-1">Destination Port</label>
          <input
            type="number"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
            value={formData.destPort}
            onChange={e => setFormData({ ...formData, destPort: parseInt(e.target.value) })}
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-1">Protocol</label>
          <select
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
            value={formData.protocol}
            onChange={e => setFormData({ ...formData, protocol: e.target.value as any })}
          >
            <option value="TCP">TCP</option>
            <option value="UDP">UDP</option>
            <option value="ICMP">ICMP</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-1">Packet Count</label>
          <input
            type="number"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
            value={formData.packetCount}
            onChange={e => setFormData({ ...formData, packetCount: parseInt(e.target.value) })}
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-400 mb-1">Total Bytes</label>
        <input
          type="number"
          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
          value={formData.totalBytes}
          onChange={e => setFormData({ ...formData, totalBytes: parseInt(e.target.value) })}
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-400 mb-2">TCP Flags</label>
        <div className="flex flex-wrap gap-2">
          {['SYN', 'ACK', 'FIN', 'RST', 'PSH', 'URG'].map(flag => (
            <button
              key={flag}
              type="button"
              onClick={() => handleFlagToggle(flag)}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                formData.flags.includes(flag)
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
              }`}
            >
              {flag}
            </button>
          ))}
        </div>
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
      >
        {isLoading ? (
          <>
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            Analyzing Traffic...
          </>
        ) : (
          <>
            Analyze Traffic
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </>
        )}
      </button>
    </form>
  );
};

export default TrafficForm;


import React from 'react';
import { AnalysisResult } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

interface AnalysisDisplayProps {
  result: AnalysisResult;
}

const AnalysisDisplay: React.FC<AnalysisDisplayProps> = ({ result }) => {
  const chartData = [
    { name: 'Risk', value: result.riskScore },
    { name: 'Safety', value: 100 - result.riskScore },
  ];

  const getRiskColor = (score: number) => {
    if (score < 30) return '#22c55e'; // Green
    if (score < 60) return '#eab308'; // Yellow
    if (score < 85) return '#f97316'; // Orange
    return '#ef4444'; // Red
  };

  const riskColor = getRiskColor(result.riskScore);

  return (
    <div className="glass p-6 rounded-2xl cyber-glow h-full">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-200">Security Assessment</h2>
          <p className="text-sm text-slate-400">AI-Powered Threat Detection</p>
        </div>
        <div 
          className="px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wider"
          style={{ backgroundColor: `${riskColor}22`, color: riskColor, border: `1px solid ${riskColor}44` }}
        >
          {result.riskScore > 40 ? 'Suspicious' : 'Normal'}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="relative h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
                startAngle={180}
                endAngle={0}
              >
                <Cell fill={riskColor} />
                <Cell fill="#1e293b" />
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center pt-8">
            <span className="text-3xl font-bold" style={{ color: riskColor }}>{result.riskScore}</span>
            <span className="text-xs text-slate-500 uppercase">Risk Score</span>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-tighter">Analysis Detail</h3>
            <p className="text-slate-200 mt-1 leading-relaxed">
              {result.explanation}
            </p>
          </div>
          
          {result.threatType && (
            <div>
              <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-tighter">Detected Pattern</h3>
              <p className="text-red-400 font-medium">{result.threatType}</p>
            </div>
          )}

          <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
            <h3 className="text-xs font-bold text-blue-400 uppercase mb-1">Recommendation</h3>
            <p className="text-sm text-slate-300 italic">
              &ldquo;{result.recommendation}&rdquo;
            </p>
          </div>
        </div>
      </div>

      <div className="mt-8 pt-6 border-t border-slate-800 flex items-center justify-between text-xs text-slate-500">
        <div className="flex items-center gap-1">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
          </svg>
          Confidence: {Math.round(result.confidence * 100)}%
        </div>
        <div>Model: Gemini-3-Flash</div>
      </div>
    </div>
  );
};

export default AnalysisDisplay;
